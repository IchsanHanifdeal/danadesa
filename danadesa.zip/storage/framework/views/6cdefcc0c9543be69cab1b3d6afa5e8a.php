<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-table"></i> Data <?php echo e($title); ?></h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <p>No Rekening : Mandiri <b>(1080026752064 a/n MUHAMMAD QOIRUL RODZ)</b></p>
                            <tr class="text-center">
                                <th>No</th>
                                <th>Pukul</th>
                                <th>Sumber</th>
                                <th>Nama Penduduk</th>
                                <th>Jumlah</th>
                                <th>Keterangan</th>
                                <th>Bukti Transfer</th>
                                <th>Validasi</th>
                                <?php if($role == 'admin'): ?>
                                    <th>Opsi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($uang_masuk->isEmpty()): ?>
                                <tr>
                                    <td colspan="8" class="text-center badge-secondary">Tidak ada Transaksi Masuk
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $uang_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $um): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($um->created_at); ?></td>
                                        <td><?php echo e(ucfirst($um->sumber)); ?></td>
                                        <td><?php echo e((optional($um->users)->nama_depan ?? 'Pemerintah') . ' ' . (optional($um->users)->nama_belakang ?? '')); ?></td>
                                        <td><?php echo e('Rp ' . number_format($um->jumlah, 2, ',', '.')); ?></td>
                                        <td><?php echo e($um->keterangan); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#modalBukti-<?php echo e($um->id_uangmasuk); ?>"> Lihat Bukti
                                                Transfer</button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modalBukti-<?php echo e($um->id_uangmasuk); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="modalPendudukLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalPendudukLabel">Bukti
                                                                transfer
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <img src="<?php echo e(asset('storage/' . $um->bukti_transfer)); ?>"
                                                                class="img-fluid" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if($um->validasi === 'diterima'): ?>
                                                <span class="badge badge-success">Diterima</span>
                                            <?php elseif($um->validasi === 'ditolak'): ?>
                                                <span class="badge badge-danger">Ditolak</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Menunggu Persetujuan</span>
                                            <?php endif; ?>
                                        </td>
                                        <?php if($role == 'admin'): ?>
                                            <td>
                                                <?php if($um->validasi === 'diterima'): ?>
                                                    <i class="fas fa-check-circle text-success"></i>
                                                <?php elseif($um->validasi === 'ditolak'): ?>
                                                    <i class="fas fa-times-circle text-danger"></i>
                                                <?php else: ?>
                                                    <button class="btn btn-success btn-sm" data-toggle="modal"
                                                        data-target="#Modalterima-<?php echo e($um->id_uangmasuk); ?>">Terima</button>

                                                    
                                                    <div class="modal fade" id="Modalterima-<?php echo e($um->id_uangmasuk); ?>"
                                                        tabindex="-1" aria-labelledby="ModalTambah" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                                        Terima uang masuk dari
                                                                        <?php echo e($um->users->nama_depan . ' ' . $um->users->nama_belakang); ?>

                                                                    </h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Apakah Anda yakin ingin menerima uang masuk dari
                                                                    <b><?php echo e($um->users->nama_depan . ' ' . $um->users->nama_belakang); ?></b>?
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">Tutup</button>
                                                                    <form
                                                                        action="<?php echo e(route('update_uangmasuk', ['id_uangmasuk' => $um->id_uangmasuk])); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('put'); ?>
                                                                        <button type="submit"
                                                                            class="btn btn-success">Ya</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    |
                                                    <button class="btn btn-danger btn-sm" data-toggle="modal"
                                                        data-target="#Modaltolak-<?php echo e($um->id_uangmasuk); ?>">Tolak</button>

                                                    <div class="modal fade" id="Modaltolak-<?php echo e($um->id_uangmasuk); ?>"
                                                        tabindex="-1" aria-labelledby="ModalTambah" aria-hidden="true">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                                        Tolak uang masuk dari
                                                                        <?php echo e($um->users->nama_depan . ' ' . $um->users->nama_belakang); ?>

                                                                    </h5>
                                                                    <button type="button" class="close"
                                                                        data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Apakah Anda yakin ingin menolak uang masuk dari
                                                                    <b><?php echo e($um->users->nama_depan . ' ' . $um->users->nama_belakang); ?></b>?
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">Tutup</button>
                                                                    <form
                                                                        action="<?php echo e(route('tolak_uangmasuk', ['id_uangmasuk' => $um->id_uangmasuk])); ?>"
                                                                        method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('put'); ?>
                                                                        <button type="submit"
                                                                            class="btn btn-success">Ya</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php if($role == 'user'): ?>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary btn-sm mt-3" data-toggle="modal"
                                data-target="#ModalTambah"><i class="fas fa-plus"></i> Tambah Transaksi</button>

                            <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="ModalTambah"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="<?php echo e(route('pendudukstore_uangmasuk')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Tambah
                                                    <?php echo e($title); ?>

                                                </h5>
                                                <button type="button" class="close" data-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="for">Sumber</label>
                                                        <input type="text" name="sumber" class="form-control"
                                                            id="sumber" value="<?php echo e(ucfirst('penduduk')); ?>"
                                                            readonly>
                                                    </div>
                                                    <div class="col-12">
                                                        <label for="nama">Nama Penduduk</label>
                                                        <input type="text" name="nama_penduduk"
                                                            class="form-control"
                                                            value="<?php echo e($nama_depan . ' ' . $nama_belakang); ?>" readonly>
                                                        <input type="number" name="id_user" class="form-control"
                                                            style="display: none;" value="<?php echo e($id_user); ?>"
                                                            readonly>
                                                    </div>
                                                    <div class="col-12">
                                                        <label for="jumlah">Jumlah</label>
                                                        <input type="number" name="jumlah" id="jumlah"
                                                            class="form-control">
                                                    </div>
                                                    <div class="col-12">
                                                        <label for="keterangan">Keterangan</label>
                                                        <textarea name="keterangan" id="keterangan" class="form-control" cols="4"></textarea>
                                                    </div>
                                                    <div class="col-12 mt-3">
                                                        <input type="file" name="bukti_transfer"
                                                            class="custom-file-input" id="foto_profil"
                                                            onchange="previewFile(this);" required>
                                                        <label class="custom-file-label" for="foto_profil">Pilih Bukti
                                                            Transfer</label>
                                                        <img id="preview" src="#" alt="Preview Foto Profil"
                                                            class="img-fluid" style="display:none;" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($role == 'admin'): ?>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-primary btn-sm mt-3" data-toggle="modal"
                                data-target="#ModalTambah"><i class="fas fa-plus"></i> Tambah Transaksi</button>

                            <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="ModalTambah"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Tambah <?php echo e($title); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('store_uangmasuk')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <label for="for">Sumber</label>
                                                        <input type="text" name="sumber" class="form-control"
                                                            id="sumber" value="<?php echo e(ucfirst('pemerintah')); ?>"
                                                            readonly>
                                                    </div>
                                                    <div class="col-12">
                                                        <label for="jumlah">Jumlah</label>
                                                        <input type="number" name="jumlah" id="jumlah"
                                                            class="form-control">
                                                    </div>
                                                    <div class="col-12">
                                                        <label for="keterangan">Keterangan</label>
                                                        <textarea name="keterangan" id="keterangan" class="form-control" cols="4"></textarea>
                                                    </div>
                                                    <div class="col-12 mt-3">
                                                        <input type="file" name="bukti_transfer"
                                                            class="custom-file-input" id="inputPreview"
                                                            onchange="previewFile(this);" required>
                                                        <label class="custom-file-label" for="inputPreview">Pilih
                                                            Bukti Transfer</label>
                                                        <img id="imagePreview" src="#"
                                                            alt="Preview Foto Profil" class="img-fluid"
                                                            style="display:none;" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-dismiss="modal">Tutup</button>
                                                <button type="submit" class="btn btn-primary"><i
                                                        class="fas fa-save"></i> Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    function previewFile(input) {
        var file = input.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').src = e.target.result;
                document.getElementById('imagePreview').style.display = 'block';
            };
            reader.readAsDataURL(file);
            input.nextElementSibling.textContent = file.name;
        }
    }
</script>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/uangmasuk.blade.php ENDPATH**/ ?>