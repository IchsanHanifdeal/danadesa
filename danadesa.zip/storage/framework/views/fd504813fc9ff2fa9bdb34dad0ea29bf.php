</div>
<!-- Main Footer -->
 <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Muhammad Qoirul Rodzikin
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#"><?php echo e(config('app.name')); ?></a>.</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo e(asset('temp/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('temp/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('temp/dist/js/adminlte.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  function confirmLogout() {
      Swal.fire({
          title: 'Apa anda Yakin?',
          text: "anda akan keluar dari sesi login?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya',
          cancelButtonText: 'Batal'
      }).then((result) => {
          if (result.isConfirmed) {
              document.getElementById('logout-form').submit();
          }
      });
  }
</script>
</body>
</html>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>