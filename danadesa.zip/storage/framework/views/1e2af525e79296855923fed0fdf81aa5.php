<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-table"></i> Data Penduduk Desa</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th>Nomor Induk Kependudukan (NIK)</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Tempat/Tanggal Lahir</th>
                                <th>Alamat</th>
                                <th>Veritifikasi</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($penduduk->isEmpty()): ?>
                                <tr>
                                    <td colspan="7" class="text-center label label-danger">Tidak ada penduduk</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $penduduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="text-center">
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($p->users->nik); ?></td>
                                        <td><?php echo e($p->users->nama_depan . ' ' . $p->users->nama_belakang); ?></td>
                                        <td>
                                            <?php if($p->jenis_kelamin == 'L'): ?>
                                                Laki-laki
                                            <?php elseif($p->jenis_kelamin == 'P'): ?>
                                                Perempuan
                                            <?php else: ?>
                                                Tidak Diketahui
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($p->tempat_lahir . '/' . $p->tanggal_lahir); ?></td>
                                        <td><?php echo e($p->alamat); ?></td>
                                        <td>
                                            <?php if($p->users->veritifikasi == 'menunggu persetujuan'): ?>
                                                <span class="badge badge-warning">Menunggu Persetujuan</span>
                                            <?php elseif($p->users->veritifikasi == 'diterima'): ?>
                                                <span class="badge badge-success">Diterima</span>
                                            <?php else: ?>
                                                <span class="badge badge-danger">Ditolak</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($p->users->veritifikasi == 'menunggu persetujuan'): ?>
                                                <button type="button" class="btn btn-info" data-toggle="modal"
                                                    data-target="#modalVeritifikasi-<?php echo e($p->id_user); ?>">
                                                    <i class="fas fa-info-circle"></i> Veritifikasi
                                                </button>
                                            <?php endif; ?>

                                            <div class="modal fade" id="modalVeritifikasi-<?php echo e($p->id_user); ?>"
                                                tabindex="-1" role="dialog"
                                                aria-labelledby="modalVeritifikasi-<?php echo e($p->id_user); ?>"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="modalPendudukLabel-<?php echo e($p->id_user); ?>">Verifikasi
                                                                Penduduk</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Apakah Anda ingin menerima atau menolak verifikasi untuk
                                                                penduduk berikut?</p>
                                                            <ul>
                                                                <li><strong>NIK:</strong> <?php echo e($p->users->nik); ?></li>
                                                                <li><strong>Nama:</strong>
                                                                    <?php echo e($p->users->nama_depan . ' ' . $p->users->nama_belakang); ?>

                                                                </li>
                                                                <li><strong>Jenis Kelamin:</strong>
                                                                    <?php echo e($p->jenis_kelamin == 'L' ? 'Laki-laki' : 'Perempuan'); ?>

                                                                </li>
                                                                <li><strong>Tempat/Tanggal Lahir:</strong>
                                                                    <?php echo e($p->tempat_lahir . '/' . $p->tanggal_lahir); ?>

                                                                </li>
                                                                <li><strong>Alamat:</strong> <?php echo e($p->alamat); ?></li>
                                                            </ul>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <form
                                                                action="<?php echo e(route('verifikasi.penduduk', $p->id_user)); ?>"
                                                                method="POST" style="display: inline;">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PATCH'); ?>
                                                                <input type="hidden" name="veritifikasi"
                                                                    value="diterima">
                                                                <button type="submit"
                                                                    class="btn btn-success">Terima</button>
                                                            </form>
                                                            <form
                                                                action="<?php echo e(route('verifikasi.penduduk', $p->id_user)); ?>"
                                                                method="POST" style="display: inline;">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PATCH'); ?>
                                                                <input type="hidden" name="veritifikasi"
                                                                    value="ditolak">
                                                                <button type="submit"
                                                                    class="btn btn-danger">Tolak</button>
                                                            </form>
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Batal</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <!-- Tombol untuk memicu modal -->
                                            <button type="button" class="btn btn-primary" data-toggle="modal"
                                                data-target="#modalPenduduk-<?php echo e($p->id_user); ?>">
                                                <i class="fas fa-info-circle"></i> Detail
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modalPenduduk-<?php echo e($p->id_user); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="modalPendudukLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalPendudukLabel">Foto Profil
                                                                Penduduk</h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <img src="<?php echo e(asset('storage/' . $p->users->foto_profil)); ?>"
                                                                alt="Foto Profil" class="img-fluid" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            |
                                            <button class="btn btn-warning" data-toggle="modal"
                                                data-target="#modal-edit-<?php echo e($p->id_penduduk); ?>"><i
                                                    class="fas fa-edit"></i> Ubah</button>

                                            <div class="modal fade" id="modal-edit-<?php echo e($p->id_penduduk); ?>"
                                                tabindex="-1" aria-labelledby="ModalEdit" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Edit
                                                                <?php echo e($title); ?></h5>
                                                            <button type="button" class="close"
                                                                data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form
                                                                action="<?php echo e(route('update_penduduk', $p->id_penduduk)); ?>"
                                                                method="POST" enctype="multipart/form-data">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <input type="file" name="foto_profil"
                                                                            class="custom-file-input" id="foto_profil"
                                                                            onchange="previewFile(this);">
                                                                        <label class="custom-file-label"
                                                                            for="foto_profil">Pilih Foto Profil</label>
                                                                        <img id="preview"
                                                                            src="<?php echo e(asset('storage/' . $p->users->foto_profil)); ?>"
                                                                            alt="Preview Foto Profil"
                                                                            class="img-fluid" />
                                                                    </div>
                                                                    <div class="col-12 mt-3">
                                                                        <label for="nik">NIK</label>
                                                                        <input type="number"
                                                                            class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                is-invalid
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="nik" id="nik"
                                                                            placeholder="NIK"
                                                                            value="<?php echo e($p->users->nik); ?>">
                                                                        <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="nama_depan">Nama Depan</label>
                                                                        <input type="text" class="form-control"
                                                                            name="nama_depan" id="nama_depan"
                                                                            placeholder="Nama Depan"
                                                                            value="<?php echo e($p->users->nama_depan); ?>">
                                                                    </div>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="nama_belakang">Nama
                                                                            Belakang</label>
                                                                        <input type="text" class="form-control"
                                                                            name="nama_belakang" id="nama_belakang"
                                                                            placeholder="Nama Belakang"
                                                                            value="<?php echo e($p->users->nama_belakang); ?>">
                                                                    </div>
                                                                    <div class="col-12 mt-3">
                                                                        <label for="jenis_kelamin">Jenis
                                                                            Kelamin</label>
                                                                        <select name="jenis_kelamin"
                                                                            id="jenis_kelamin" class="form-control">
                                                                            <option value="">--- Pilih Jenis
                                                                                Kelamin ---</option>
                                                                            <option value="L"
                                                                                <?php echo e($p->jenis_kelamin == 'L' ? 'selected' : ''); ?>>
                                                                                Laki-laki</option>
                                                                            <option value="P"
                                                                                <?php echo e($p->jenis_kelamin == 'P' ? 'selected' : ''); ?>>
                                                                                Perempuan</option>
                                                                        </select>
                                                                    </div>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="tempat_lahir">Tempat Lahir</label>
                                                                        <input type="text" class="form-control"
                                                                            name="tempat_lahir" id="tempat_lahir"
                                                                            placeholder="Tempat Lahir"
                                                                            value="<?php echo e($p->tempat_lahir); ?>">
                                                                    </div>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="tanggal_lahir">Tanggal
                                                                            Lahir</label>
                                                                        <input type="date" class="form-control"
                                                                            name="tanggal_lahir" id="tanggal_lahir"
                                                                            placeholder="Tanggal Lahir"
                                                                            value="<?php echo e($p->tanggal_lahir); ?>">
                                                                    </div>
                                                                    <div class="col-12 mt-3">
                                                                        <label for="alamat">Alamat</label>
                                                                        <textarea class="form-control" name="alamat" id="alamat" placeholder="alamat" cols="4"><?php echo e($p->alamat); ?></textarea>
                                                                    </div>
                                                                    <hr>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="username">Username</label>
                                                                        <input type="text"
                                                                            class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="username" id="username"
                                                                            placeholder="Username"
                                                                            value="<?php echo e($p->users->username); ?>">
                                                                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="col-6 mt-3">
                                                                        <label for="email">Email</label>
                                                                        <input type="email"
                                                                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="email" id="username"
                                                                            placeholder="Email"
                                                                            value=" <?php echo e($p->users->email); ?>">
                                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                    <div class="col-12 mt-3">
                                                                        <label for="old_password">Password Lama</label>
                                                                        <input type="password"
                                                                            class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="old_password" id="old_password"
                                                                            placeholder="Masukkan password lama">
                                                                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                    <div class="col-12 mt-3">
                                                                        <label for="new_password">Password Baru</label>
                                                                        <input type="password"
                                                                            class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="new_password" id="new_password"
                                                                            placeholder="Masukkan password baru">
                                                                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                    <div class="col-12 mt-3">
                                                                        <label
                                                                            for="new_password_confirmation">Konfirmasi
                                                                            Password Baru</label>
                                                                        <input type="password"
                                                                            class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                            name="new_password_confirmation"
                                                                            id="new_password_confirmation"
                                                                            placeholder="Konfirmasi password baru">
                                                                        <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?></div>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Tutup</button>
                                                            <button type="submit" class="btn btn-primary"><i
                                                                    class="fas fa-save"></i>
                                                                Simpan</button>
                                                        </div>
                                                    </div>
                                                    </form>
                                                </div>
                                            </div>
                                            |

                                            
                                            <button type="button" class="btn btn-danger" data-toggle="modal"
                                                data-target="#modal-hapus-<?php echo e($p->id_penduduk); ?>"><i
                                                    class="fas fa-trash"></i> Hapus</button>


                                            
                                            <div class="modal fade" id="modal-hapus-<?php echo e($p->id_penduduk); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="modal-hapusLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modal-hapusLabel">
                                                                Konfirmasi
                                                                Hapus Data</h5>
                                                            <button type="button" class="close"
                                                                data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            Apakah Anda yakin ingin menghapus data penduduk
                                                            <b><?php echo e($p->users->nik); ?></b>?
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Tutup</button>
                                                            <form
                                                                action="<?php echo e(route('destroy_penduduk', ['id_user' => $p->id_user])); ?>"
                                                                method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button type="submit"
                                                                    class="btn btn-danger">Hapus</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end">
                        <button class="btn btn-primary btn-sm mt-2" type="button" data-toggle="modal"
                            data-target="#ModalTambah"><i class="fas fa-plus"></i> Tambah</button>

                        <!-- Modal Tambah -->
                        <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="ModalTambah"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Tambah <?php echo e($title); ?>

                                        </h5>
                                        <button type="button" class="close" data-dismiss="modal"
                                            aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form action="<?php echo e(route('store_penduduk')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-12">
                                                    <input type="file" name="foto_profil"
                                                        class="custom-file-input" id="foto_profil"
                                                        onchange="previewFile(this);" required>
                                                    <label class="custom-file-label" for="foto_profil">Pilih Foto
                                                        Profil</label>
                                                    <img id="preview" src="#" alt="Preview Foto Profil"
                                                        class="img-fluid" style="display:none;" />
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <label for="nik">NIK</label>
                                                    <input type="number"
                                                        class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        is-invalid
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="nik" id="nik" placeholder="NIK"
                                                        value="<?php echo e(old('nik')); ?>">
                                                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-6 mt-3">
                                                    <label for="nama_depan">Nama Depan</label>
                                                    <input type="text" class="form-control" name="nama_depan"
                                                        id="nama_depan" placeholder="Nama Depan"
                                                        value="<?php echo e(old('nama_depan')); ?>">
                                                </div>
                                                <div class="col-6 mt-3">
                                                    <label for="nama_belakang">Nama Belakang</label>
                                                    <input type="text" class="form-control" name="nama_belakang"
                                                        id="nama_belakang" placeholder="Nama Belakang"
                                                        value="<?php echo e(old('nama_belakang')); ?>">
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <label for="jenis_kelamin">Jenis Kelamin</label>
                                                    <select name="jenis_kelamin" id="jenis_kelamin"
                                                        class="form-control">
                                                        <option value="">--- Pilih Jenis Kelamin ---</option>
                                                        <option value="L">Laki-laki</option>
                                                        <option value="P">Perempuan</option>
                                                    </select>
                                                </div>
                                                <div class="col-6 mt-3">
                                                    <label for="tempat_lahir">Tempat Lahir</label>
                                                    <input type="text" class="form-control" name="tempat_lahir"
                                                        id="tempat_lahir" placeholder="Tempat Lahir">
                                                </div>
                                                <div class="col-6 mt-3">
                                                    <label for="tanggal_lahir">Tanggal Lahir</label>
                                                    <input type="date" class="form-control" name="tanggal_lahir"
                                                        id="tanggal_lahir" placeholder="Tanggal Lahir">
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <label for="alamat">Alamat</label>
                                                    <textarea class="form-control" name="alamat" id="alamat" placeholder="alamat" cols="4"></textarea>
                                                </div>
                                                <hr>
                                                <div class="col-6 mt-3">
                                                    <label for="username">Username</label>
                                                    <input type="text"
                                                        class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="username" id="username" placeholder="Username"
                                                        value="<?php echo e(old('username')); ?>">
                                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-6 mt-3">
                                                    <label for="email">Email</label>
                                                    <input type="email"
                                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="email" id="username" placeholder="Email"
                                                        value=" <?php echo e(old('email')); ?>">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-12 mt-3">
                                                    <label for="password">Password</label>
                                                    <input type="password"
                                                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        name="password" id="password" placeholder="Password"
                                                        placeholder="Password">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Tutup</button>
                                        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i>
                                            Simpan</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('temp/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('temp/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('temp/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('temp/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('temp/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>

<script>
    $(function() {
        $("#example1").DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
        });
    });
</script>

<script>
    function previewFile(input) {
        var file = input.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview').src = e.target.result;
                document.getElementById('preview').style.display = 'block';
            };
            reader.readAsDataURL(file);

            input.nextElementSibling.textContent = file.name;
        }
    }
</script>

<script>
    function previewFile(input) {
        var file = input.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('preview').src = e.target.result;
            };
            reader.readAsDataURL(file);

            input.nextElementSibling.textContent = file.name;
        }
    }
</script>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/penduduk.blade.php ENDPATH**/ ?>