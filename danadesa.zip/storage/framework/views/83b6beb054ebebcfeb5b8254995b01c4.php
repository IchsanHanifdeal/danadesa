<?php
    $title = 'Error 404';
    $foto_profil = 'Error 404';
    $nama_depan = 'Error 404';
    $nama_belakang = 'Error 404';
    $active = 'error 404';
?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main content -->
<section class="content">
    <div class="error-page">
        <h2 class="headline text-warning"> 404</h2>

        <div class="error-content">
            <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! Halaman tidak ditemukan.</h3>

            <p>
                We could not find the page you were looking for.
                Meanwhile, you may <a href="<?php echo e(route('dashboard')); ?>">return to dashboard</a> or try using the search form.
            </p>

        </div>
        <!-- /.error-content -->
    </div>
    <!-- /.error-page -->
</section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/errors/404.blade.php ENDPATH**/ ?>