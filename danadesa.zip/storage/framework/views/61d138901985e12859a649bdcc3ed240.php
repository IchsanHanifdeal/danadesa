<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="card col-lg-10">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-table"></i> Laporan Keuangan Desa</h3>
                </div>
                
                <div class="card-body">
                    <div class="box-body">
                        <form method="get" action="<?php echo e(route('laporan')); ?>">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Pilih Bulan</label>
                                        <input type="month" class="form-control" name="month" value="<?php echo e($month); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Jenis Sumber</label>
                                        <select class="form-control" name="sumber">
                                            <option value="">Semua</option>
                                            <option value="penduduk" <?php echo e($filter_sumber == 'penduduk' ? 'selected' : ''); ?>>Penduduk</option>
                                            <option value="pemerintah" <?php echo e($filter_sumber == 'pemerintah' ? 'selected' : ''); ?>>Pemerintah</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <div class="form-group w-100">
                                        <input type="submit" value="TAMPILKAN" class="btn btn-sm btn-primary btn-block">
                                    </div>
                                </div>
                            </div>
                        </form>                        
                    </div>
                    
                    <div class="row" style="display: none;">
                        <div class="col-lg-6">
                            <table class="table table-bordered">
                                <tr>
                                    <th width="30%">DARI TANGGAL</th>
                                    <th width="1%">:</th>
                                    <td id="display_start_date"></td>
                                </tr>
                                <tr>
                                    <th>SAMPAI TANGGAL</th>
                                    <th>:</th>
                                    <td id="display_end_date"></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Kategori</th>
                                <th>Keterangan</th>
                                <th>Pemasukan</th>
                                <th>Pengeluaran</th>
                                <th>Dokumentasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="text-center">
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($item['tanggal']); ?></td>
                                    <td><?php echo e($item['kategori']); ?></td>
                                    <td><?php echo e($item['keterangan']); ?></td>
                                    <td class="text-right">
                                        <?php echo e($item['pemasukan'] ? number_format($item['pemasukan']) : '-'); ?></td>
                                    <td class="text-right">
                                        <?php echo e($item['pengeluaran'] ? number_format($item['pengeluaran']) : '-'); ?></td>
                                    <td>
                                        <?php if($item['dokumentasi']): ?>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                                data-target="#modalBukti-<?php echo e($index); ?>">
                                                Lihat Dokumentasi
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modalBukti-<?php echo e($index); ?>" tabindex="-1"
                                                role="dialog" aria-labelledby="modalPendudukLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalPendudukLabel">Dokumentasi
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <img src="<?php echo e(asset('storage/' . ($item['kategori'] === 'Pemasukan' ? 'bukti_transfer/' : 'dokumentasi/') . $item['dokumentasi'])); ?>"
                                                                class="img-fluid" alt="Dokumentasi" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="7">
                                        <?php echo e($isFiltered ? 'Tidak ada transaksi di tanggal ini' : 'Silahkan filter terlebih dahulu'); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>

                            <?php if(count($data) > 0): ?>
                                <tr class="text-center font-weight-bold">
                                    <td colspan="4">Total</td>
                                    <td class="text-right"><?php echo e(number_format($total_pemasukan)); ?></td>
                                    <td class="text-right"><?php echo e(number_format($total_pengeluaran)); ?></td>
                                    <td></td>
                                </tr>
                                <tr class="text-center font-weight-bold">
                                    <td colspan="4">Saldo</td>
                                    <td colspan="2" class="text-right"><?php echo e(number_format($saldo)); ?></td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    document.getElementById('filterForm').addEventListener('submit', function(event) {
        event.preventDefault();

        var startDate = document.getElementById('start_date').value;
        var endDate = document.getElementById('end_date').value;

        document.getElementById('display_start_date').innerText = startDate;
        document.getElementById('display_end_date').innerText = endDate;

        document.querySelector('.result-table').style.display = 'block';
    });
</script>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/laporan.blade.php ENDPATH**/ ?>