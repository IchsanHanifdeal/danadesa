<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row d-flex justify-content-center">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><i class="fas fa-table"></i> Data <?php echo e($title); ?></h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table id="example2" class="table table-bordered table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Keterangan</th>
                                <th>Dokumentasi</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($uang_keluar->isEmpty()): ?>
                                <tr>
                                    <td colspan="5" class="text-center badge-secondary">Tidak ada Transaksi Keluar
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $uang_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($uk->tanggal); ?></td>
                                        <td><?php echo e($uk->keterangan); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalBukti-<?php echo e($uk->id_uangkeluar); ?>"> Lihat Dokumentasi</button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modalBukti-<?php echo e($uk->id_uangkeluar); ?>"
                                                tabindex="-1" role="dialog" aria-labelledby="modalPendudukLabel"
                                                aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="modalPendudukLabel">Dokumentasi
                                                            </h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <img src="<?php echo e(asset('storage/' . $uk->dokumentasi)); ?>"
                                                                class="img-fluid" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e('Rp ' . number_format($uk->jumlah, 2, ',', '.')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php if($role == 'admin'): ?>
                        <div class="d-flex justify-content-end mt-3">
                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal"
                                data-target="#ModalTambah"><i class="fas fa-plus"></i> Tambah Transaksi</button>
                        </div>

                        <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="ModalTambah"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Tambah <?php echo e($title); ?> </h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('store_uangkeluar')); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <label for="tanggal">Tanggal</label>
                                                    <input type="date" name="tanggal" id="tanggal"
                                                        class="form-control"
                                                        value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                                                </div>
                                                <div class="col-md-12 mt-2">
                                                    <label for="Keterangan">Keterangan</label>
                                                    <textarea name="keterangan" id="keterangan" rows="4" class="form-control"></textarea>
                                                </div>
                                                <div class="col-12 mt-2">
                                                    <input type="file" name="dokumentasi" class="custom-file-input"
                                                        id="inputPreview" onchange="previewFile(this);" required>
                                                    <label class="custom-file-label" for="inputPreview">Pilih
                                                        Dokumentasi</label>
                                                    <img id="imagePreview" src="#" alt="Preview Dokumentasi"
                                                        class="img-fluid" style="display:none;" />
                                                </div>
                                                <div class="col-12 mt-2">
                                                    <label for="jumlah">Jumlah</label>
                                                    <input type="number" name="jumlah" id="jumlah"
                                                        class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary"
                                                data-dismiss="modal">Tutup</button>
                                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i>
                                                Simpan</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
\
<script>
    function previewFile(input) {
        var file = input.files[0];
        if (file) {
            var reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').src = e.target.result;
                document.getElementById('imagePreview').style.display = 'block';
            };
            reader.readAsDataURL(file);
            input.nextElementSibling.textContent = file.name;
        }
    }
</script>
<?php /**PATH D:\Ichsan Hanifdeal\laravel\danadesa\resources\views/uangkeluar.blade.php ENDPATH**/ ?>